document.addEventListener("DOMContentLoaded", function () {
  "use strict";
  const ADMIN_WHATSAPP = "233537747322";
  const HISTORY_KEY = "servicesPlugRequests";
  const form = document.getElementById("requestForm");
  const serviceSelect = document.getElementById("service");
  const locationInput = document.getElementById("location");
  const gpsBtn = document.getElementById("gpsBtn");
  const toast = document.getElementById("toast");
  const historyList = document.getElementById("requestHistory");
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  function readJSON(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || ""); }
    catch (_) { return fallback; }
  }

  function createRequestId() {
    const now = new Date();
    const yy = String(now.getFullYear()).slice(-2);
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const dd = String(now.getDate()).padStart(2, "0");
    const day = yy + mm + dd;
    const key = "servicesPlugDailyCount";
    const saved = readJSON(key, {}) || {};
    const count = saved.day === day ? (Number(saved.count) || 0) + 1 : 1;
    localStorage.setItem(key, JSON.stringify({ day: day, count: count }));
    return "SP-" + day + "-" + String(count).padStart(3, "0");
  }

  function safeText(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (char) {
      return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char];
    });
  }

  function loadHistory() {
    if (!historyList) return;
    const requests = readJSON(HISTORY_KEY, []);
    if (!Array.isArray(requests) || !requests.length) {
      historyList.innerHTML = '<p class="empty-history">No requests on this device yet.</p>';
      return;
    }
    historyList.innerHTML = requests.slice(0, 5).map(function (item) {
      return '<div class="history-item"><div><strong>' + safeText(item.id) +
        '</strong><small>' + safeText(item.service) + ' · ' + safeText(item.date) +
        '</small></div><span class="history-status">' + safeText(item.status) + '</span></div>';
    }).join("");
  }

  function saveRequest(request) {
    const requests = readJSON(HISTORY_KEY, []);
    const list = Array.isArray(requests) ? requests : [];
    list.unshift(request);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(list.slice(0, 10)));
    loadHistory();
  }

  document.querySelectorAll("[data-service]").forEach(function (button) {
    button.addEventListener("click", function () {
      serviceSelect.value = button.getAttribute("data-service") || "";
      document.getElementById("request").scrollIntoView({ behavior: "smooth" });
      window.setTimeout(function () { locationInput.focus({ preventScroll: true }); }, 450);
    });
  });

  if (gpsBtn) {
    gpsBtn.addEventListener("click", function () {
      if (!navigator.geolocation) {
        alert("GPS is not supported. Please type your area or landmark.");
        return;
      }
      gpsBtn.textContent = "…";
      gpsBtn.disabled = true;
      navigator.geolocation.getCurrentPosition(function (position) {
        const lat = position.coords.latitude.toFixed(6);
        const lng = position.coords.longitude.toFixed(6);
        locationInput.value = "GPS: " + lat + ", " + lng;
        locationInput.dataset.map = "https://www.google.com/maps?q=" + lat + "," + lng;
        gpsBtn.textContent = "✓";
        gpsBtn.disabled = false;
        if (toast) toast.textContent = "Map location captured. Please review the rest of the form.";
      }, function () {
        gpsBtn.textContent = "⌖";
        gpsBtn.disabled = false;
        alert("Location access was not allowed. Please type your area or landmark.");
      }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });
    });
  }

  if (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      const service = serviceSelect.value.trim();
      const location = locationInput.value.trim();
      const problem = document.getElementById("problem").value.trim();
      const name = document.getElementById("name").value.trim();
      const phone = document.getElementById("phone").value.trim();
      if (!service || !location || !problem || !name || !phone) {
        alert("Please complete all the fields.");
        return;
      }

      const requestId = createRequestId();
      const mapLink = locationInput.dataset.map || "";
      const date = new Date().toLocaleDateString();
      let message = "🔧 SERVICES PLUG REQUEST\n\n" +
        "Request ID: " + requestId + "  |  NEW\n\n" +
        "SERVICE\n" + service + "\n\n" +
        "LOCATION\n" + location + "\n" +
        (mapLink ? "📍 Google Maps: " + mapLink + "\n\n" : "\n") +
        "CUSTOMER\n" + name + "  |  " + phone + "\n\n" +
        "PROBLEM\n" + problem;

      saveRequest({ id: requestId, service: service, status: "NEW", date: date });
      if (toast) toast.textContent = "Opening WhatsApp with your request details…";
      const whatsappURL = "https://wa.me/" + ADMIN_WHATSAPP + "?text=" + encodeURIComponent(message);
      window.location.href = whatsappURL;
    });
  }
  loadHistory();
});
