SERVICES PLUG CUSTOMER WEBSITE — V3
===================================
This is a visual and usability upgrade of the customer-facing website.

FILES
- index.html
- style.css
- app.js
- Assets/ (five supplied images)

DEPLOY
Upload/replace these files in the root of the existing customer website repository.
Keep the folder name exactly "Assets" (capital A), because the HTML references Assets/...
Commit the changes and allow Vercel/GitHub Pages to redeploy.

CURRENT BEHAVIOR
- Service buttons preselect the matching service in the request form.
- GPS can fill coordinates and a Google Maps link when the user grants location permission.
- Submitting creates a local request ID and opens a prefilled WhatsApp message to the configured admin number.
- The recent request list is stored in that visitor's browser only.

IMPORTANT LIMITATION
This version is NOT connected to the Services Plug Admin dashboard or a shared database.
Local history is not centrally stored and does not provide live request status.
Secure backend/database integration must be implemented separately.
